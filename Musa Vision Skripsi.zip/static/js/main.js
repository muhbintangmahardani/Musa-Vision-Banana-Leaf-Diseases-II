/**
 * MUSAVISION EDITORIAL EDITION — CLIENT-SIDE JAVASCRIPT CONTROLLER
 * Desain: TaniScan Minimalist Editorial UI (100% Anti-AI Slop)
 * Aturan: Strict Zero-Emojis, Clean Monoline SVGs, JetBrains Mono Telemetry
 * Fitur: Deteksi YOLO26n, CIE-LAB CLAHE, Gatekeeper 4-Lapis, Split Verdict Card,
 *        Collapsible Drawer Skripsi, Riwayat Uji (.CSV), dan Evaluasi SUS (John Brooke 1996)
 */

let currentFile = null;
let lastResponseData = null;
let currentVerdictView = "annotated";

const SUS_QUESTIONS = [
  "Saya berpikir akan sering menggunakan sistem deteksi penyakit daun pisang ini.",
  "Saya merasa sistem ini terlalu rumit untuk digunakan secara mandiri.",
  "Saya merasa sistem ini sangat mudah untuk digunakan dalam proses deteksi kebun.",
  "Saya membutuhkan bantuan orang lain atau teknisi ahli untuk menggunakan sistem ini.",
  "Saya merasa fungsi dan fitur pada sistem ini terintegrasi dengan sangat baik.",
  "Saya merasa ada terlalu banyak hal yang tidak konsisten pada sistem ini.",
  "Saya merasa kebanyakan petani atau pengguna umum akan cepat memahami sistem ini.",
  "Saya merasa sistem ini sangat membingungkan saat pertama kali dioperasikan.",
  "Saya merasa sangat percaya diri saat menggunakan sistem ini di lapangan.",
  "Saya perlu mempelajari banyak hal terlebih dahulu sebelum dapat menggunakan sistem ini."
];

// ==============================================================================
// 1. UTILITAS SANITASI ANTI-AI SLOP (ZERO EMOJIS MANDATE)
// ==============================================================================
function cleanText(str) {
  if (!str) return "";
  return String(str)
    .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2300}-\u{23FF}\u{2B50}\u{200D}\u{FE0F}]/gu, "")
    .trim();
}
const stripEmojis = cleanText;

// ==============================================================================
// 2. INISIALISASI HALAMAN
// ==============================================================================
document.addEventListener("DOMContentLoaded", () => {
  currentLocalPreviewUrl = "";
  currentFile = null;
  initEventListeners();
  loadSampleGallery();
  renderHistoryTable();
  renderSusQuestions();
  renderSusTable();
  initNavbarScroll();
  initLenisSmoothScroll();
  initTitleWordSplitAndScrollTrigger();
  initCardMotionAnimations();
  initScrollAnimations();
  initHeroLoadAnimations();
  initNavPillWatcher();
  initHeroSlider();

  // Slider realtime counter
  const confSlider = document.getElementById("confSlider");
  const confValue = document.getElementById("confValue");
  if (confSlider && confValue) {
    confSlider.addEventListener("input", (e) => {
      confValue.textContent = parseFloat(e.target.value).toFixed(2);
    });
  }

  // Keyboard escape for lightbox
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { closeLightbox(); closePathogenDetailModal(); }
  });
});

// ==============================================================================
// 3. NAVIGASI HALAMAN & DYNAMIC ACTIVE NAV PILL WATCHER (SMOOTH ACTIVE PILL)
// ==============================================================================
let isManualNavigating = false;
// ==============================================================================
// 2.5 HERO SLIDER CAROUSEL (3 GAMBAR SMOOTH AUTO-SLIDE 5.5s)
// ==============================================================================
let currentHeroSlide = 0;
let heroSlideTimer = null;

const HERO_SLIDES = [
  {
    main: "Deteksi Cerdas untuk",
    serif: "Perkebunan Masa Depan",
    subtitle: "Identifikasi lima kelas patologi helai daun pisang secara objektif dalam hitungan milidetik menggunakan YOLO26n nano, adaptasi CIE-LAB CLAHE, serta rotasi fungisida FRAC."
  },
  {
    main: "Optimalisasi Kanopi Daun,",
    serif: "Menjaga Tandan Produktif",
    subtitle: "Pertahankan minimal 6 hingga 8 helai daun fungsional sehat per pohon hingga masa panen dengan panduan sanitasi pemangkasan daun berpenyakit yang terukur dan presisi."
  },
  {
    main: "Proteksi Presisi,",
    serif: "Rotasi Standar FRAC",
    subtitle: "Cegah resistensi jamur patogen Sigatoka dan Cordana melalui rotasi tepat bahan aktif triazol, strobilurin, dan fungisida kontak protektif berstandar internasional."
  }
];

function setHeroSlide(idx) {
  currentHeroSlide = (idx + HERO_SLIDES.length) % HERO_SLIDES.length;
  const track = document.getElementById("heroSlideTrack");
  if (track) {
    track.style.transform = `translateX(-${(currentHeroSlide * 100) / 3}%)`;
  }

  const hMain = document.getElementById("heroHeadlineMain");
  const hSerif = document.getElementById("heroHeadlineSub");
  const hSub = document.getElementById("heroSubtitle");

  const slideData = HERO_SLIDES[currentHeroSlide];
  if (slideData) {
    if (typeof gsap !== "undefined") {
      gsap.to([hMain, hSerif, hSub], {
        opacity: 0,
        y: -6,
        duration: 0.2,
        ease: "power2.in",
        onComplete: () => {
          if (hMain) {
            delete hMain.dataset.wordsSplit;
            hMain.textContent = slideData.main;
          }
          if (hSerif) {
            delete hSerif.dataset.wordsSplit;
            hSerif.textContent = slideData.serif;
          }
          if (hSub) hSub.textContent = slideData.subtitle;

          const wordsMain = hMain ? splitElementIntoWords(hMain) : [];
          const wordsSerif = hSerif ? splitElementIntoWords(hSerif) : [];
          const allHeadlineWords = [...wordsMain, ...wordsSerif];

          gsap.set(allHeadlineWords, { yPercent: 110, opacity: 0, rotateZ: 2 });
          gsap.set([hMain, hSerif], { opacity: 1, y: 0 });
          gsap.set(hSub, { opacity: 0, y: 10 });

          gsap.to(allHeadlineWords, {
            yPercent: 0,
            opacity: 1,
            rotateZ: 0,
            duration: 0.65,
            stagger: 0.038,
            ease: "power3.out"
          });

          gsap.to(hSub, {
            opacity: 1,
            y: 0,
            duration: 0.5,
            delay: 0.1,
            ease: "power2.out"
          });
        }
      });
    } else {
      if (hMain) hMain.textContent = slideData.main;
      if (hSerif) hSerif.textContent = slideData.serif;
      if (hSub) hSub.textContent = slideData.subtitle;
    }
  }

  const dots = document.querySelectorAll(".hero-dot");
  dots.forEach((dot, i) => {
    if (i === currentHeroSlide) {
      dot.className = "hero-dot w-6 h-1.5 rounded-full bg-[#B6F035] transition-all duration-300";
    } else {
      dot.className = "hero-dot w-2 h-1.5 rounded-full bg-white/40 hover:bg-white/75 transition-all duration-300";
    }
  });
}
window.setHeroSlide = setHeroSlide;

function initHeroSlider() {
  if (heroSlideTimer) clearInterval(heroSlideTimer);
  heroSlideTimer = setInterval(() => {
    setHeroSlide(currentHeroSlide + 1);
  }, 5500);
}
window.initHeroSlider = initHeroSlider;

let manualNavTimer = null;

function updateActiveNavPill(targetSectionId) {
  if (!targetSectionId) return;
  const targetHref = `#${targetSectionId}`;

  // Update desktop links
  const desktopLinks = document.querySelectorAll(".desktop-nav-menu .nav-pill-link");
  desktopLinks.forEach((link) => {
    const href = link.getAttribute("href");
    if (href === targetHref) {
      link.classList.add("nav-pill-active");
    } else {
      link.classList.remove("nav-pill-active");
    }
  });

  // Update mobile links
  const mobileLinks = document.querySelectorAll("#mobileMenuDrawer .nav-pill-link");
  mobileLinks.forEach((link) => {
    const href = link.getAttribute("href");
    if (href === targetHref) {
      link.classList.add("nav-pill-active");
    } else {
      link.classList.remove("nav-pill-active");
    }
  });
}
window.updateActiveNavPill = updateActiveNavPill;

function initNavPillWatcher() {
  const allNavAnchors = document.querySelectorAll('.desktop-nav-menu .nav-pill-link, #mobileMenuDrawer .nav-pill-link, #mobileMenuDrawer a[href^="#"]');

  allNavAnchors.forEach((a) => {
    a.addEventListener("click", (e) => {
      const href = a.getAttribute("href");
      if (!href || !href.startsWith("#")) return;
      e.preventDefault();
      const targetId = href.substring(1);

      // Kunci scrollspy sesaat saat smooth scroll berjalan
      isManualNavigating = true;
      clearTimeout(manualNavTimer);
      updateActiveNavPill(targetId);

      const targetEl = document.getElementById(targetId);
      if (targetEl) {
        const navHeight = 90;
        const rect = targetEl.getBoundingClientRect();
        const targetY = rect.top + window.pageYOffset - navHeight;
        window.scrollTo({ top: Math.max(0, targetY), behavior: "smooth" });
      }

      toggleMobileMenu(true);
      manualNavTimer = setTimeout(() => {
        isManualNavigating = false;
      }, 900);
    });
  });

  // ScrollSpy otomatis berpresisi tinggi untuk seluruh seksi halaman
  const sections = ["hero-section", "solution-section", "scan-section", "bento-section", "pathogen-section", "metrics-view", "faq-section"];
  let ticking = false;

  window.addEventListener(
    "scroll",
    () => {
      if (isManualNavigating) return;

      if (!ticking) {
        window.requestAnimationFrame(() => {
          const scrollY = window.pageYOffset || document.documentElement.scrollTop;
          if (scrollY < 120) {
            updateActiveNavPill("hero-section");
            ticking = false;
            return;
          }

          // Cek apakah user berada di area bawah / footer
          if (window.innerHeight + scrollY >= document.documentElement.scrollHeight - 250) {
            updateActiveNavPill("faq-section");
            ticking = false;
            return;
          }

          // Garis probe viewport (32% dari atas layar)
          const probeY = window.innerHeight * 0.32;
          let activeSec = "hero-section";

          for (const secId of sections) {
            const el = document.getElementById(secId);
            if (el) {
              const rect = el.getBoundingClientRect();
              if (rect.top <= probeY && rect.bottom > probeY) {
                activeSec = secId;
                break;
              }
            }
          }

          updateActiveNavPill(activeSec);
          ticking = false;
        });
        ticking = true;
      }
    },
    { passive: true }
  );
}

// 3.5 FAQ INTERAKTIF (AGROVIA STYLE ACCORDION WITH CENTERED SVG PLUS/MINUS)
function toggleAgroviaFaq(idx) {
  const allFaqItems = document.querySelectorAll(".agrovia-faq-item");
  allFaqItems.forEach((item, i) => {
    const content = item.querySelector(".faq-content");
    const vertLine = item.querySelector(".faq-vert-line");
    const svgBox = item.querySelector(".faq-svg-box");

    if (!content) return;

    if (i + 1 === idx) {
      const isOpen = content.classList.contains("is-open");
      if (isOpen) {
        content.classList.remove("is-open");
        content.style.maxHeight = "0px";
        if (vertLine) vertLine.classList.remove("opacity-0");
        if (svgBox) {
          svgBox.classList.remove("bg-[#229B45]", "text-white", "border-transparent");
          svgBox.classList.add("bg-white", "text-[#111812]");
        }
      } else {
        content.classList.add("is-open");
        content.style.maxHeight = (content.scrollHeight + 35) + "px";
        if (vertLine) vertLine.classList.add("opacity-0");
        if (svgBox) {
          svgBox.classList.remove("bg-white", "text-[#111812]");
          svgBox.classList.add("bg-[#229B45]", "text-white", "border-transparent");
        }
      }
    } else {
      content.classList.remove("is-open");
      content.style.maxHeight = "0px";
      if (vertLine) vertLine.classList.remove("opacity-0");
      if (svgBox) {
        svgBox.classList.remove("bg-[#229B45]", "text-white", "border-transparent");
        svgBox.classList.add("bg-white", "text-[#111812]");
      }
    }
  });
}
window.toggleAgroviaFaq = toggleAgroviaFaq;

function switchMainView(viewName) {
  if (viewName === "metrics") {
    const el = document.getElementById("metrics-view");
    if (el) {
      const navHeight = 90;
      const rect = el.getBoundingClientRect();
      const targetY = rect.top + window.pageYOffset - navHeight;
      window.scrollTo({ top: Math.max(0, targetY), behavior: "smooth" });
    }
    updateActiveNavPill("metrics-view");
  } else {
    const el = document.getElementById("scan-section") || document.getElementById("hero-section");
    if (el) {
      const navHeight = 90;
      const rect = el.getBoundingClientRect();
      const targetY = rect.top + window.pageYOffset - navHeight;
      window.scrollTo({ top: Math.max(0, targetY), behavior: "smooth" });
    }
    updateActiveNavPill("hero-section");
  }
}

function switchView(viewName) {
  switchMainView(viewName);
}
window.switchView = switchView;
window.switchMainView = switchMainView;

function scrollToWorkspace() {
  const ws = document.getElementById("core-workspace");
  if (ws) {
    ws.scrollIntoView({ behavior: "smooth" });
  }
}

function switchTab(tabId) {
  // Kompatibilitas aman untuk pemanggilan tab terprogram
  if (tabId === "tab-history" || tabId === "tab-sus") {
    switchMainView("metrics");
    setTimeout(() => {
      const target = document.getElementById(tabId);
      if (target) target.scrollIntoView({ behavior: "smooth" });
    }, 120);
  } else if (tabId === "tab-detect") {
    switchMainView("scanner");
    scrollToWorkspace();
  }
}

// ==============================================================================
// 4. EVENT LISTENERS UNGGAH FILE & KAMERA
// ==============================================================================
let currentLocalPreviewUrl = null;

function initEventListeners() {
  const imageInput = document.getElementById("imageInput");
  const cameraInput = document.getElementById("cameraInput");

  if (imageInput) {
    imageInput.addEventListener("change", (e) => {
      if (e.target.files && e.target.files[0]) {
        handleSelectedFile(e.target.files[0]);
      }
    });
  }

  if (cameraInput) {
    cameraInput.addEventListener("change", (e) => {
      if (e.target.files && e.target.files[0]) {
        handleSelectedFile(e.target.files[0]);
      }
    });
  }

  // Dukungan klik langsung dan keyboard untuk trigger upload & kamera desktop
  const btnUpload = document.getElementById("btnUploadImageTrigger");
  if (btnUpload) {
    btnUpload.addEventListener("click", (e) => {
      if (e.target.tagName !== "INPUT" && imageInput) {
        imageInput.click();
      }
    });
    btnUpload.addEventListener("keydown", (e) => {
      if ((e.key === "Enter" || e.key === " ") && imageInput) {
        e.preventDefault();
        imageInput.click();
      }
    });
  }

  const btnCamera = document.getElementById("btnCameraTrigger");
  if (btnCamera) {
    btnCamera.addEventListener("click", (e) => {
      if (e.target.tagName !== "INPUT" && cameraInput) {
        cameraInput.click();
      }
    });
    btnCamera.addEventListener("keydown", (e) => {
      if ((e.key === "Enter" || e.key === " ") && cameraInput) {
        e.preventDefault();
        cameraInput.click();
      }
    });
  }

  // Event listener tombol switcher citra aktif
  const btnAnnotated = document.getElementById("btnSwitchAnnotated");
  const btnClahe = document.getElementById("btnSwitchClahe");
  const btnOrig = document.getElementById("btnSwitchOrig");

  if (btnAnnotated) {
    btnAnnotated.addEventListener("click", (e) => {
      e.preventDefault();
      switchVerdictView("annotated");
    });
  }
  if (btnClahe) {
    btnClahe.addEventListener("click", (e) => {
      e.preventDefault();
      switchVerdictView("clahe");
    });
  }
  if (btnOrig) {
    btnOrig.addEventListener("click", (e) => {
      e.preventDefault();
      switchVerdictView("orig");
    });
  }
}

function handleSelectedFile(file) {
  currentFile = file;
  const fileNameBadge = document.getElementById("selectedFileName");
  const fileNameText = document.getElementById("fileNameText");
  if (fileNameBadge && fileNameText) {
    fileNameText.textContent = cleanText(file.name);
    fileNameBadge.classList.remove("hidden");
  }

  // Pratinjau langsung di Mobile & iPad
  const previewBox = document.getElementById("controlImagePreviewBox");
  const previewImg = document.getElementById("controlPreviewImg");
  const previewBadge = document.getElementById("controlPreviewBadge");
  const emptyPrompt = document.getElementById("controlEmptyPrompt");
  const previewOverlay = document.getElementById("controlPreviewOverlay");
  if (previewBox && previewImg) {
    previewImg.src = URL.createObjectURL(file);
    previewImg.classList.remove("hidden");
    if (emptyPrompt) emptyPrompt.classList.add("hidden");
    if (previewOverlay) previewOverlay.classList.remove("hidden");
    if (previewBadge) previewBadge.textContent = `Foto: ${cleanText(file.name.substring(0, 16))}`;
    previewBox.classList.remove("hidden");
  }

  // Pratinjau lokal pada kanvas
  const activeDisplayImg = document.getElementById("activeDisplayImg");
  const verdictActiveImg = document.getElementById("verdictActiveImg");
  const emptyPlaceholder = document.getElementById("verdictEmptyPlaceholder");
  const wsPlaceholder = document.getElementById("workspacePlaceholder");

  const reader = new FileReader();
  reader.onload = (e) => {
    currentLocalPreviewUrl = e.target.result;
    currentLoadedSampleUrl = null;
    if (wsPlaceholder) wsPlaceholder.classList.add("hidden");
    if (activeDisplayImg) {
      activeDisplayImg.src = currentLocalPreviewUrl;
      activeDisplayImg.classList.remove("hidden");
    }
    if (verdictActiveImg) verdictActiveImg.src = currentLocalPreviewUrl;
    if (emptyPlaceholder) emptyPlaceholder.classList.add("hidden");

    // Perbarui foto pada Seksi 4 dengan berkas unggahan pengguna
    const solImg = document.getElementById("solutionTelemetryImg");
    if (solImg) solImg.src = currentLocalPreviewUrl;
  };
  reader.readAsDataURL(file);
}

function clearSelectedFile() {
  currentFile = null;
  currentLocalPreviewUrl = null;
  const imageInput = document.getElementById("imageInput");
  const cameraInput = document.getElementById("cameraInput");
  const fileNameBadge = document.getElementById("selectedFileName");
  const activeDisplayImg = document.getElementById("activeDisplayImg");
  const verdictActiveImg = document.getElementById("verdictActiveImg");
  const emptyPlaceholder = document.getElementById("verdictEmptyPlaceholder");

  if (imageInput) imageInput.value = "";
  if (cameraInput) cameraInput.value = "";
  if (fileNameBadge) fileNameBadge.classList.add("hidden");
  if (activeDisplayImg) activeDisplayImg.src = "";
  if (verdictActiveImg) verdictActiveImg.src = "";
  if (emptyPlaceholder) emptyPlaceholder.classList.remove("hidden");
}

// ==============================================================================
// 5. EKSEKUSI PREDIKSI (POST /predict)
// ==============================================================================
async function runPrediction() {
  if (!currentFile) {
    alert("Silakan pilih atau ambil foto helai daun pisang terlebih dahulu.");
    return;
  }

  const predictBtn = document.getElementById("predictBtn");
  if (predictBtn) {
    predictBtn.disabled = true;
    predictBtn.classList.add("opacity-75", "cursor-wait");
    predictBtn.innerHTML = `
      <div class="inline-block w-4 h-4 border-2 border-[#111812] border-t-transparent rounded-full animate-spin"></div>
      <span>Memindai...</span>
    `;
  }

  const idleBox = document.getElementById("idleBox");
  const loadingBox = document.getElementById("loadingBox");
  const rejectedBox = document.getElementById("rejectedBox");
  const noDetectionBox = document.getElementById("noDetectionBox");
  const agronomyBox = document.getElementById("agronomyBox");
  const emptyPlaceholder = document.getElementById("verdictEmptyPlaceholder");

  const initialEmptyBox = document.getElementById("initialEmptyBox");
  const visualResultBox = document.getElementById("visualResultBox");
  if (initialEmptyBox) initialEmptyBox.classList.add("hidden");
  if (visualResultBox) visualResultBox.classList.add("hidden");
  if (idleBox) idleBox.classList.add("hidden");
  if (rejectedBox) rejectedBox.classList.add("hidden");
  if (noDetectionBox) noDetectionBox.classList.add("hidden");
  if (agronomyBox) agronomyBox.classList.add("hidden");
  if (emptyPlaceholder) emptyPlaceholder.classList.add("hidden");

  // Aktifkan Detektor Garis Naik-Turun CUKUP SATU SAJA di Kolom Kanan (Workspace)
  const controlLaser = document.getElementById("controlLaserScan");
  const controlOverlay = document.getElementById("controlLaserOverlay");
  const workspaceLaser = document.getElementById("workspaceLaserScan");
  const workspaceOverlay = document.getElementById("workspaceLaserOverlay");

  // Pratinjau kiri tidak menggunakan animasi detektor
  if (controlLaser) controlLaser.classList.add("hidden");
  if (controlOverlay) controlOverlay.classList.add("hidden");
  if (workspaceLaser) workspaceLaser.classList.remove("hidden");
  if (workspaceOverlay) workspaceOverlay.classList.remove("hidden");
  if (loadingBox) loadingBox.classList.add("hidden");

  const formData = new FormData();
  formData.append("image", currentFile);
  formData.append("conf_threshold", document.getElementById("confSlider").value);
  formData.append(
    "use_clahe",
    document.getElementById("useClaheToggle").checked ? "true" : "false"
  );
  formData.append(
    "bypass_gatekeeper",
    document.getElementById("bypassGatekeeper").checked ? "true" : "false"
  );

  const tStartClient = performance.now();
  try {
    const res = await fetch("/predict", { method: "POST", body: formData });
    const data = await res.json();
    const clientRoundtripMs = (performance.now() - tStartClient).toFixed(2);

    if (loadingBox) loadingBox.classList.add("hidden");

    if (data.status === "error") {
      alert(data.message || "Terjadi kesalahan pada pemrosesan server.");
      if (idleBox) idleBox.classList.remove("hidden");
      return;
    }

    lastResponseData = data;

    // --------------------------------------------------------------------------
    // KASUS 1: DITOLAK OLEH GATEKEEPER
    // --------------------------------------------------------------------------
    if (data.status === "rejected") {
      if (rejectedBox) rejectedBox.classList.remove("hidden");
      if (visualResultBox) visualResultBox.classList.add("hidden");
      if (initialEmptyBox) initialEmptyBox.classList.add("hidden");

      const rTitle = document.getElementById("rejectedTitle");
      if (rTitle && data.title) {
        rTitle.textContent = cleanText(data.title);
      }

      const rReason = document.getElementById("rejectedReason");
      if (rReason && data.reason) {
        rReason.textContent = cleanText(data.reason);
      }

      const rMetrics = document.getElementById("rejectedMetrics");
      if (rMetrics && data.metrics) {
        const gy = data.metrics.green_yellow_pct !== undefined ? data.metrics.green_yellow_pct : 0;
        const bot = data.metrics.botanical_pct || 0;
        let cat = "Bukan Objek Daun Pisang";
        if (data.rejection_type === "ai_generated") cat = "Citra Sintetis AI";
        rMetrics.textContent = `Klasifikasi: ${cat} | Klorofil: ${gy}% | Lamina: ${bot}%`;
      }
      return;
    }

    // --------------------------------------------------------------------------
    // KASUS 2 & 3: CITRA LOLOS (NO_DETECTION ATAU BERHASIL DETEKSI)
    // --------------------------------------------------------------------------
    // Perbarui gambar aktif di verdict card
    const activeDisplayImg = document.getElementById("activeDisplayImg");
    const verdictActiveImg = document.getElementById("verdictActiveImg");
    if (data.images) {
      if (activeDisplayImg) activeDisplayImg.src = data.images.annotated_b64;
      if (verdictActiveImg) verdictActiveImg.src = data.images.annotated_b64;
      currentVerdictView = "annotated";
      updateSwitcherActiveBtn("annotated");
    }

    // Perbarui elemen visual multi-kanal pratinjau bawah
    const imgOrig = document.getElementById("imgOrig");
    const imgClahe = document.getElementById("imgClahe");
    const imgAnnotated = document.getElementById("imgAnnotated");
    const phOrig = document.getElementById("phImgOrig");
    const phClahe = document.getElementById("phImgClahe");
    const phAnnotated = document.getElementById("phImgAnnotated");
    const bdOrig = document.getElementById("badgeImgOrig");
    const bdClahe = document.getElementById("badgeImgClahe");
    const bdAnnotated = document.getElementById("badgeImgAnnotated");
    const claheBadge = document.getElementById("claheBadge");

    if (imgOrig && data.images) {
      imgOrig.src = data.images.original_b64;
      imgOrig.classList.remove("hidden");
      if (phOrig) phOrig.classList.add("hidden");
      if (bdOrig) bdOrig.classList.remove("hidden");
    }
    if (imgClahe && data.images) {
      imgClahe.src = data.images.clahe_b64;
      imgClahe.classList.remove("hidden");
      if (phClahe) phClahe.classList.add("hidden");
      if (bdClahe) bdClahe.classList.remove("hidden");
    }
    if (imgAnnotated && data.images) {
      imgAnnotated.src = data.images.annotated_b64;
      imgAnnotated.classList.remove("hidden");
      if (phAnnotated) phAnnotated.classList.add("hidden");
      if (bdAnnotated) bdAnnotated.classList.remove("hidden");
    }
    if (claheBadge) claheBadge.textContent = data.use_clahe ? "CIE-LAB CLAHE: Aktif" : "CIE-LAB CLAHE: Nonaktif";

    // Telemetri Seksi 3
    const totalDet = document.getElementById("totalDetCount");
    const lesionCount = document.getElementById("lesionCount");
    const leafCount = document.getElementById("leafCount");
    const latPre = document.getElementById("latPre");
    const latInf = document.getElementById("latInf");
    const latPost = document.getElementById("latPost");
    const latServer = document.getElementById("latServer");
    const latClient = document.getElementById("latClient");

    if (totalDet) totalDet.textContent = data.total_detections || 0;
    if (lesionCount) lesionCount.textContent = data.lesion_level_count || 0;
    if (leafCount) leafCount.textContent = data.leaf_level_count || 0;

    if (data.telemetry) {
      if (latPre) latPre.textContent = `${data.telemetry.preprocess_ms} ms`;
      if (latInf) latInf.textContent = `${data.telemetry.inference_nms_ms} ms`;
      if (latPost) latPost.textContent = `${data.telemetry.postprocess_ms} ms`;
      if (latServer) latServer.textContent = `${data.telemetry.server_total_ms} ms`;
    }
    if (latClient) latClient.textContent = `${clientRoundtripMs} ms`;

    // Kasus No Detection
    if (data.status === "no_detection") {
      if (noDetectionBox) noDetectionBox.classList.remove("hidden");
      if (visualResultBox) visualResultBox.classList.add("hidden");
      if (initialEmptyBox) initialEmptyBox.classList.add("hidden");
      return;
    }

    // Kasus Berhasil Deteksi
    if (data.agronomy) {
      if (agronomyBox) agronomyBox.classList.remove("hidden");
      if (visualResultBox) visualResultBox.classList.remove("hidden");
      if (initialEmptyBox) initialEmptyBox.classList.add("hidden");
      const ag = data.agronomy;

      const agroName = document.getElementById("agroName");
      const agroSci = document.getElementById("agroSci");
      const agroSev = document.getElementById("agroSeverity");
      const agroSym = document.getElementById("agroSymptoms");
      const agroDeleaf = document.getElementById("agroDeleafing");
      const agroFracText = document.getElementById("agroFracText");
      const agroDisc = document.getElementById("agroDisclaimer");
      const agroBadges = document.getElementById("agroFracBadges");

      if (agroName) agroName.textContent = cleanText(ag.display_name);
      if (agroSci) agroSci.textContent = cleanText(ag.scientific_name);
      if (agroSev) {
        const rawSev = cleanText(ag.severity_category || "");
        const sevLower = (rawSev + " " + (ag.display_name || "")).toLowerCase();
        let displayLabel = rawSev;

        if (sevLower.includes("ganas") || sevLower.includes("hitam") || sevLower.includes("kritis")) {
          displayLabel = "Ganas / Fase Lanjut";
          agroSev.style.background = "#dc2626";
          agroSev.style.border = "1px solid #b91c1c";
          agroSev.style.color = "#ffffff";
        } else if (sevLower.includes("sehat") || sevLower.includes("optimal")) {
          displayLabel = "Sehat Optimal";
          agroSev.style.background = "#15803d";
          agroSev.style.border = "1px solid #166534";
          agroSev.style.color = "#ffffff";
        } else {
          // Sedang / Ringan / Sekunder (Pestalotiopsis, Cordana, Sigatoka Kuning)
          displayLabel = "Sekunder / Ringan-Sedang";
          agroSev.style.background = "#d97706";
          agroSev.style.border = "1px solid #b45309";
          agroSev.style.color = "#ffffff";
        }

        agroSev.textContent = displayLabel;
        agroSev.style.fontWeight = "700";
        agroSev.style.borderRadius = "9999px";
        agroSev.style.padding = "4px 14px";
        agroSev.style.fontSize = "12px";
        agroSev.style.whiteSpace = "nowrap";
      }

      // Update Posisi Penanda Spektrum Keparahan Real-Time
      const severityMarker = document.getElementById("severityMarker");
      if (severityMarker) {
        const sevLower = ((ag.severity_category || "") + " " + (ag.display_name || "")).toLowerCase();
        let leftPct = 88;
        if (sevLower.includes("sehat") || sevLower.includes("optimal")) {
          leftPct = 8;
        } else if (sevLower.includes("pestalotiopsis") || sevLower.includes("ringan") || sevLower.includes("sekunder")) {
          leftPct = 28;
        } else if (sevLower.includes("cordana") || sevLower.includes("kuning") || sevLower.includes("sedang")) {
          leftPct = 55;
        } else if (sevLower.includes("ganas") || sevLower.includes("hitam") || sevLower.includes("fijiensis") || sevLower.includes("kritis")) {
          leftPct = 88;
        }
        severityMarker.style.transition = "left 0.7s cubic-bezier(0.34, 1.56, 0.64, 1)";
        severityMarker.style.left = `${leftPct}%`;
      }
      if (agroSym) agroSym.textContent = cleanText(ag.symptoms);
      if (agroDeleaf) agroDeleaf.textContent = cleanText(ag.deleafing_protocol);
      if (agroFracText) agroFracText.textContent = cleanText(ag.frac_recommendation);
      if (agroDisc) agroDisc.textContent = cleanText(ag.ppl_disclaimer);

      // Sinkronisasi teks solusi pencegahan langsung pada kartu diagnosis
      const diagDeleaf = document.getElementById("diagDeleafingText");
      if (diagDeleaf) diagDeleaf.textContent = cleanText(ag.deleafing_protocol);

      const diagFrac = document.getElementById("diagFracText");
      if (diagFrac) diagFrac.textContent = cleanText(ag.frac_recommendation);

      const diagDisc = document.getElementById("diagDisclaimerText");
      if (diagDisc) diagDisc.textContent = cleanText(ag.ppl_disclaimer);

      // Confidence Bar
      let maxConf = 0;
      if (data.detections && data.detections.length > 0) {
        maxConf = Math.max(...data.detections.map((d) => d.confidence_pct || 0));
      } else if (ag.confidence) {
        maxConf = parseFloat(ag.confidence);
      }

      const confPctEl = document.getElementById("verdictConfPct");
      const confBarEl = document.getElementById("verdictConfBar");
      if (confPctEl) confPctEl.textContent = `${maxConf.toFixed(1)}%`;
      if (confBarEl) {
        confBarEl.style.width = "0%";
        setTimeout(() => {
          confBarEl.style.width = `${Math.min(100, maxConf)}%`;
        }, 80);
      }

      if (agroBadges) {
        agroBadges.innerHTML = (ag.frac_codes || [])
          .map((code) => `<span class="px-2.5 py-0.5 rounded-full text-[11px] font-mono bg-[#B6F035]/30 text-[#111812] font-semibold">${cleanText(code)}</span>`)
          .join(" ");
      }

      const agroFracShort = document.getElementById("agroFracShort");
      if (agroFracShort) {
        const fracCodes = (ag.frac_codes || []).map(cleanText).filter(Boolean);
        if (fracCodes.length > 0) {
          agroFracShort.innerHTML = fracCodes
            .map(code => {
              const displayCode = code.startsWith("FRAC") ? code : `FRAC ${code}`;
              return `<div class="flex items-start gap-2 bg-[#F5F6F4] p-2.5 rounded-xl border border-slate-200/80">
                <div class="w-4 h-4 rounded-full bg-[#229B45]/15 text-[#229B45] flex items-center justify-center shrink-0 mt-0.5">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                </div>
                <div class="text-xs font-mono font-semibold text-[#111812] leading-snug">${displayCode}</div>
              </div>`;
            })
            .join("");
        } else {
          agroFracShort.innerHTML = `<div class="flex items-center gap-2 bg-[#F5F6F4] p-2.5 rounded-xl border border-slate-200/80">
            <div class="w-4 h-4 rounded-full bg-[#229B45]/15 text-[#229B45] flex items-center justify-center shrink-0">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>
            </div>
            <div class="text-xs font-medium text-[#229B45]">Optimal &amp; Sehat (Tidak memerlukan rotasi fungisida)</div>
          </div>`;
        }
      }

      // Sinkronkan foto dan data ke Kartu Telemetri Seksi 4
      updateSolutionTelemetryCard(data);
    }

    // Tabel Bounding Box Detail (Rapi dengan Padding py-3 px-4 & Badge Presisi)
    const bboxBody = document.getElementById("bboxTableBody");
    if (bboxBody && data.detections) {
      if (data.detections.length === 0) {
        bboxBody.innerHTML = `
          <tr>
            <td colspan="6" class="py-6 px-4 text-center text-xs text-[#68706A]">
              Tidak ada lesi bercak daun yang melebihi ambang batas keyakinan.
            </td>
          </tr>`;
      } else {
        bboxBody.innerHTML = data.detections
          .map(
            (d) => `
          <tr class="hover:bg-slate-50/80 transition border-b border-slate-100">
            <td class="py-3 px-4 font-mono font-bold text-xs text-[#111812]">${d.id}</td>
            <td class="py-3 px-4 font-medium text-xs text-[#111812]">${cleanText(d.class_name)}</td>
            <td class="py-3 px-4 font-mono font-bold text-xs text-[#229B45]">${d.confidence_pct}%</td>
            <td class="py-3 px-4 font-mono text-xs text-[#4A554D]">${d.box_area_ratio_pct}%</td>
            <td class="py-3 px-4 text-xs">
              <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium ${
                d.granularity.includes("Lesion")
                  ? "bg-rose-50 text-rose-700 border border-rose-200"
                  : "bg-emerald-50 text-emerald-800 border border-emerald-200"
              }">
                ${cleanText(d.granularity)}
              </span>
            </td>
            <td class="py-3 px-4 font-mono text-xs text-[#68706A]">[${d.bbox.join(", ")}]</td>
          </tr>
        `
          )
          .join("");
      }
    }

    // Simpan ke Riwayat
    saveToHistory({
      timestamp: new Date().toLocaleString("id-ID"),
      filename: currentFile.name,
      use_clahe: data.use_clahe ? "Aktif" : "Nonaktif",
      dominant_class: data.dominant_class || "Tidak Terdeteksi",
      lesion_count: data.lesion_level_count || 0,
      leaf_count: data.leaf_level_count || 0,
      server_ms: data.telemetry ? data.telemetry.server_total_ms : 0,
      client_ms: clientRoundtripMs,
    });
  } catch (err) {
    if (loadingBox) loadingBox.classList.add("hidden");
    if (idleBox) idleBox.classList.remove("hidden");
    alert("Gagal menghubungi server: " + err.message);
  } finally {
    // Matikan Garis Detektor Laser Scanline
    const controlLaser = document.getElementById("controlLaserScan");
    const controlOverlay = document.getElementById("controlLaserOverlay");
    const workspaceLaser = document.getElementById("workspaceLaserScan");
    const workspaceOverlay = document.getElementById("workspaceLaserOverlay");
    if (controlLaser) controlLaser.classList.add("hidden");
    if (controlOverlay) controlOverlay.classList.add("hidden");
    if (workspaceLaser) workspaceLaser.classList.add("hidden");
    if (workspaceOverlay) workspaceOverlay.classList.add("hidden");
    if (loadingBox) loadingBox.classList.add("hidden");

    const predictBtn = document.getElementById("predictBtn");
    if (predictBtn) {
      predictBtn.disabled = false;
      predictBtn.classList.remove("opacity-75", "cursor-wait");
      predictBtn.innerHTML = `
        <span>Jalankan Deteksi YOLO26n</span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <line x1="5" y1="12" x2="19" y2="12"></line>
          <polyline points="12 5 19 12 12 19"></polyline>
        </svg>
      `;
    }
  }
}

// ==============================================================================
// 6. VIEW SWITCHER PADA VERDICT CARD
// ==============================================================================
function switchVerdictView(view) {
  currentVerdictView = view;
  const activeDisplayImg = document.getElementById("activeDisplayImg");
  const verdictActiveImg = document.getElementById("verdictActiveImg");

  let targetSrc = "";
  if (lastResponseData && lastResponseData.images) {
    if (view === "annotated") {
      targetSrc = lastResponseData.images.annotated_b64;
    } else if (view === "orig") {
      targetSrc = lastResponseData.images.original_b64;
    } else if (view === "clahe") {
      targetSrc = lastResponseData.images.clahe_b64;
    }
  } else if (currentLocalPreviewUrl) {
    targetSrc = currentLocalPreviewUrl;
  }

  if (targetSrc) {
    if (activeDisplayImg) activeDisplayImg.src = targetSrc;
    if (verdictActiveImg) verdictActiveImg.src = targetSrc;
  }

  updateSwitcherActiveBtn(view);

  const modeStatusText = document.getElementById("modeStatusText");
  if (modeStatusText) {
    if (view === "annotated") modeStatusText.textContent = "YOLO26n BBox";
    else if (view === "clahe") modeStatusText.textContent = "CIE-LAB CLAHE";
    else if (view === "orig") modeStatusText.textContent = "Citra Asli";
  }
}

function cycleVerdictView() {
  const views = ["annotated", "clahe", "orig"];
  const currentIdx = views.indexOf(currentVerdictView);
  const nextIdx = (currentIdx + 1) % views.length;
  switchVerdictView(views[nextIdx]);
}
window.cycleVerdictView = cycleVerdictView;

function toggleAgroviaAccordion(idx) {
  for (let i = 1; i <= 4; i++) {
    const content = document.getElementById(`accContent${i}`);
    const vertLine = document.getElementById(`accVertLine${i}`);
    const svgBox = document.getElementById(`accSvgBox${i}`);

    if (!content) continue;

    if (i === idx) {
      const isOpen = content.classList.contains("is-open");
      if (isOpen) {
        content.classList.remove("is-open");
        content.style.maxHeight = "0px";
        if (vertLine) vertLine.classList.remove("opacity-0");
        if (svgBox) {
          svgBox.classList.remove("bg-[#B6F035]", "border-transparent");
          svgBox.classList.add("bg-white", "text-[#111812]");
        }
      } else {
        content.classList.add("is-open");
        content.style.maxHeight = (content.scrollHeight + 35) + "px";
        if (vertLine) vertLine.classList.add("opacity-0");
        if (svgBox) {
          svgBox.classList.remove("bg-white", "text-[#111812]");
          svgBox.classList.add("bg-[#B6F035]", "text-[#111812]", "border-transparent");
        }
      }
    } else {
      content.classList.remove("is-open");
      content.style.maxHeight = "0px";
      const otherVert = document.getElementById(`accVertLine${i}`);
      const otherSvg = document.getElementById(`accSvgBox${i}`);
      if (otherVert) otherVert.classList.remove("opacity-0");
      if (otherSvg) {
        otherSvg.classList.remove("bg-[#B6F035]", "border-transparent");
        otherSvg.classList.add("bg-white", "text-[#111812]");
      }
    }
  }
}
window.toggleAgroviaAccordion = toggleAgroviaAccordion;

function updateSwitcherActiveBtn(view) {
  const btnAnnotated = document.getElementById("btnSwitchAnnotated");
  const btnOrig = document.getElementById("btnSwitchOrig");
  const btnClahe = document.getElementById("btnSwitchClahe");

  [btnAnnotated, btnOrig, btnClahe].forEach((b) => {
    if (b) {
      b.classList.remove("bg-[#B6F035]", "text-[#111812]", "font-semibold");
      b.classList.add("text-white/80");
    }
  });

  if (view === "annotated" && btnAnnotated) {
    btnAnnotated.classList.add("bg-[#B6F035]", "text-[#111812]", "font-semibold");
    btnAnnotated.classList.remove("text-white/80");
  }
  if (view === "orig" && btnOrig) {
    btnOrig.classList.add("bg-[#B6F035]", "text-[#111812]", "font-semibold");
    btnOrig.classList.remove("text-white/80");
  }
  if (view === "clahe" && btnClahe) {
    btnClahe.classList.add("bg-[#B6F035]", "text-[#111812]", "font-semibold");
    btnClahe.classList.remove("text-white/80");
  }
}

// ==============================================================================
// 7. FILTER KATALOG PATOGEN (SEKSI 5)
// ==============================================================================
function filterPathogens(category) {
  const buttons = document.querySelectorAll(".filter-pill");
  buttons.forEach((btn) => {
    if (btn.dataset.filter === category) btn.classList.add("active");
    else btn.classList.remove("active");
  });

  const cards = document.querySelectorAll(".pathogen-item-card");
  cards.forEach((card) => {
    if (category === "all" || card.dataset.category === category) {
      card.style.display = "flex";
    } else {
      card.style.display = "none";
    }
  });
}

// ==============================================================================
// 8. RIWAYAT UJI KEBUN (LOCALSTORAGE & CSV)
// ==============================================================================
function saveToHistory(record) {
  try {
    const list = JSON.parse(localStorage.getItem("musa_vision_history") || "[]");
    list.unshift(record);
    if (list.length > 50) list.pop();
    localStorage.setItem("musa_vision_history", JSON.stringify(list));
    renderHistoryTable();
  } catch (e) {
    console.error("Gagal menyimpan riwayat:", e);
  }
}

function renderHistoryTable() {
  const tbody = document.getElementById("historyTableBody");
  const countEl = document.getElementById("history-count");
  if (!tbody) return;

  try {
    const list = JSON.parse(localStorage.getItem("musa_vision_history") || "[]");
    if (countEl) countEl.textContent = list.length;

    if (list.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" class="text-center py-6 px-4 text-xs text-[#68706A]">
            Belum ada data pengujian yang tercatat. Silakan jalankan pemindaian daun.
          </td>
        </tr>`;
      return;
    }

    tbody.innerHTML = list
      .map(
        (item) => `
      <tr class="hover:bg-slate-50/80 transition border-b border-slate-100">
        <td class="py-3 px-4 font-mono text-xs text-[#4A554D] whitespace-nowrap">${item.timestamp}</td>
        <td class="py-3 px-4 font-medium text-xs text-[#111812] max-w-[160px] truncate" title="${cleanText(item.filename)}">${cleanText(item.filename)}</td>
        <td class="py-3 px-4 font-semibold text-xs text-[#111812]">${cleanText(item.dominant_class)}</td>
        <td class="py-3 px-4 font-mono text-xs text-[#4A554D]">${item.use_clahe}</td>
        <td class="py-3 px-4 font-mono text-xs text-[#111812]">${item.lesion_count} / ${item.leaf_count}</td>
        <td class="py-3 px-4 font-mono text-xs font-semibold text-[#229B45] whitespace-nowrap">${item.server_ms} ms</td>
        <td class="py-3 px-4 font-mono text-xs text-[#68706A] whitespace-nowrap">${item.client_ms} ms</td>
      </tr>`
      )
      .join("");
  } catch (e) {
    console.error("Gagal merender tabel riwayat:", e);
  }
}

function exportHistoryCSV() {
  const list = JSON.parse(localStorage.getItem("musa_vision_history") || "[]");
  if (list.length === 0) {
    alert("Tidak ada data riwayat untuk diekspor.");
    return;
  }

  const headers = [
    "Waktu Sesi",
    "Nama File",
    "Status CLAHE",
    "Vonis Dominan",
    "Bercak Lesion (<35%)",
    "Cakupan Leaf (>=35%)",
    "Latensi Server (ms)",
    "Roundtrip Klien (ms)",
  ];

  const rows = list.map((item) => [
    `"${item.timestamp}"`,
    `"${cleanText(item.filename)}"`,
    `"${item.use_clahe}"`,
    `"${cleanText(item.dominant_class)}"`,
    item.lesion_count,
    item.leaf_count,
    item.server_ms,
    item.client_ms,
  ]);

  const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
  downloadCSV(csvContent, "musa_vision_riwayat_uji.csv");
}

function clearHistory() {
  if (confirm("Apakah Anda yakin ingin menghapus seluruh log riwayat pengujian?")) {
    localStorage.removeItem("musa_vision_history");
    renderHistoryTable();
  }
}

// ==============================================================================
// 9. EVALUASI USABILITAS SISTEM (SUS - JOHN BROOKE 1996)
// ==============================================================================
function renderSusQuestions() {
  const container = document.getElementById("susQuestionsContainer");
  if (!container) return;

  container.innerHTML = SUS_QUESTIONS.map(
    (q, idx) => `
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm">
      <div class="text-xs sm:text-sm font-medium text-[#111812] leading-relaxed break-words flex-1 pr-2">
        <span class="font-bold font-mono text-[#229B45] mr-1">${idx + 1}.</span> ${q}
      </div>
      <div class="grid grid-cols-5 gap-1.5 w-full md:w-64 shrink-0">
        ${[1, 2, 3, 4, 5]
          .map(
            (val) => `
          <label class="cursor-pointer flex flex-col items-center justify-center py-2 px-1 rounded-xl border border-slate-200 hover:border-[#229B45] hover:bg-[#B6F035]/10 transition text-center min-h-[44px]">
            <input type="radio" name="sus_q_${idx}" value="${val}" onchange="updateLiveSusScore()" class="accent-[#229B45] cursor-pointer mb-1" />
            <span class="font-mono text-xs font-bold text-[#111812]">${val}</span>
            <span class="text-[9px] text-[#68706A] leading-none">${val === 1 ? 'STS' : val === 5 ? 'SS' : ''}</span>
          </label>
        `
          )
          .join("")}
      </div>
    </div>`
  ).join("");
}

function updateLiveSusScore() {
  let score = calculateCurrentSus();
  const scoreEl = document.getElementById("currentSusScore");
  const gradeEl = document.getElementById("currentSusGrade");

  if (scoreEl) scoreEl.textContent = score !== null ? score.toFixed(1) : "0.0";
  if (gradeEl) {
    if (score === null) {
      gradeEl.textContent = "Status: Belum Lengkap";
    } else {
      let grade = "F (Tidak Dapat Diterima)";
      if (score >= 80.3) grade = "A (Unggul / Excellent)";
      else if (score >= 68.0) grade = "B (Baik / Good)";
      else if (score >= 51.0) grade = "C (Cukup / Marginal)";
      gradeEl.textContent = `Predikat: ${grade}`;
    }
  }
}

function calculateCurrentSus() {
  let answers = [];
  for (let i = 0; i < 10; i++) {
    const selected = document.querySelector(`input[name="sus_q_${i}"]:checked`);
    if (!selected) return null;
    answers.push(parseInt(selected.value));
  }

  let oddSum = 0;
  for (let i = 0; i < 10; i += 2) oddSum += answers[i] - 1;

  let evenSum = 0;
  for (let i = 1; i < 10; i += 2) evenSum += 5 - answers[i];

  return (oddSum + evenSum) * 2.5;
}

function saveSusResponse() {
  const nameInput = document.getElementById("susName");
  const roleInput = document.getElementById("susRole");
  const score = calculateCurrentSus();

  if (score === null) {
    alert("Harap jawab seluruh 10 pertanyaan kuesioner SUS terlebih dahulu.");
    return;
  }

  const respondentName = nameInput && nameInput.value.trim() ? nameInput.value.trim() : "Anonim";
  const respondentRole = roleInput && roleInput.value.trim() ? roleInput.value.trim() : "Petani/Pengguna Umum";

  let grade = "Marginal";
  if (score >= 80.3) grade = "Excellent (A)";
  else if (score >= 68.0) grade = "Good (B)";
  else if (score < 51.0) grade = "Poor (F)";

  const newRecord = {
    timestamp: new Date().toLocaleString("id-ID"),
    name: respondentName,
    role: respondentRole,
    score: score.toFixed(1),
    grade: grade,
  };

  const list = JSON.parse(localStorage.getItem("musa_vision_sus_records") || "[]");
  list.unshift(newRecord);
  localStorage.setItem("musa_vision_sus_records", JSON.stringify(list));

  alert(`Kuesioner SUS berhasil disimpan dengan skor ${score.toFixed(1)} (${grade})!`);

  if (nameInput) nameInput.value = "";
  if (roleInput) roleInput.value = "";
  for (let i = 0; i < 10; i++) {
    const sel = document.querySelector(`input[name="sus_q_${i}"]:checked`);
    if (sel) sel.checked = false;
  }
  updateLiveSusScore();
  renderSusTable();
}

function renderSusTable() {
  const tbody = document.getElementById("susTableBody");
  const avgEl = document.getElementById("avgSusScore");
  if (!tbody) return;

  try {
    const list = JSON.parse(localStorage.getItem("musa_vision_sus_records") || "[]");

    if (list.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="5" class="text-center py-6 text-xs text-[#636E66]">
            Belum ada rekapitulasi data responden SUS.
          </td>
        </tr>`;
      if (avgEl) avgEl.textContent = "0.0";
      return;
    }

    const totalScore = list.reduce((acc, cur) => acc + parseFloat(cur.score), 0);
    const avgScore = (totalScore / list.length).toFixed(1);
    if (avgEl) avgEl.textContent = avgScore;

    tbody.innerHTML = list
      .map(
        (item) => `
      <tr>
        <td class="font-mono text-xs">${item.timestamp}</td>
        <td class="font-medium text-xs">${cleanText(item.name)}</td>
        <td class="text-xs">${cleanText(item.role)}</td>
        <td class="font-mono text-xs font-bold text-[#229B45]">${item.score}</td>
        <td class="text-xs font-medium">${item.grade}</td>
      </tr>`
      )
      .join("");
  } catch (e) {
    console.error("Gagal merender tabel SUS:", e);
  }
}

function exportSUSCSV() {
  const list = JSON.parse(localStorage.getItem("musa_vision_sus_records") || "[]");
  if (list.length === 0) {
    alert("Tidak ada data evaluasi SUS untuk diekspor.");
    return;
  }

  const headers = ["Waktu Pengisian", "Nama Responden", "Peran", "Skor SUS (100)", "Predikat"];
  const rows = list.map((item) => [
    `"${item.timestamp}"`,
    `"${cleanText(item.name)}"`,
    `"${cleanText(item.role)}"`,
    item.score,
    `"${item.grade}"`,
  ]);

  const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
  downloadCSV(csvContent, "musa_vision_evaluasi_sus.csv");
}

function downloadCSV(csvContent, filename) {
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.setAttribute("href", url);
  a.setAttribute("download", filename);
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

// ==============================================================================
// 10. LIGHTBOX FULLSCREEN PREVIEW & DOWNLOAD
// ==============================================================================
function openLightbox(src, caption) {
  if (!src) return;
  const modal = document.getElementById("lightboxModal");
  const img = document.getElementById("lightboxImg");
  const cap = document.getElementById("lightboxCaption");
  if (img) img.src = src;
  if (cap) cap.textContent = caption || "Pratinjau Citra Resolusi Penuh";
  if (modal) {
    modal.classList.remove("hidden");
    document.body.classList.add("overflow-hidden");
  }
}

function closeLightbox() {
  const modal = document.getElementById("lightboxModal");
  if (modal) modal.classList.add("hidden");
  document.body.classList.remove("overflow-hidden");
}

function openLightboxFullscreen() {
  let src = "";
  let caption = "";

  if (lastResponseData && lastResponseData.images) {
    if (currentVerdictView === "clahe") {
      src = lastResponseData.images.clahe_b64;
      caption = "Prapemrosesan Penajaman Mikrokontras CIE-LAB CLAHE (Kanal L)";
    } else if (currentVerdictView === "orig") {
      src = lastResponseData.images.original_b64;
      caption = "Citra Asli Helai Daun Pisang (Raw RGB)";
    } else {
      src = lastResponseData.images.annotated_b64;
      caption = `Hasil Deteksi YOLO26n: ${cleanText(lastResponseData.dominant_class || "Bercak Daun")}`;
    }
  } else if (currentLocalPreviewUrl) {
    src = currentLocalPreviewUrl;
    caption = "Pratinjau Citra Helai Daun Pisang";
  } else {
    alert("Silakan pilih citra daun atau jalankan analisis terlebih dahulu.");
    return;
  }

  openLightbox(src, caption);
  syncLightboxTabs(currentVerdictView);
}

function switchLightboxTab(mode) {
  currentVerdictView = mode;
  updateSwitcherActiveBtn(mode);
  syncLightboxTabs(mode);

  const activeDisplayImg = document.getElementById("activeDisplayImg");
  const verdictActiveImg = document.getElementById("verdictActiveImg");
  const lbImg = document.getElementById("lightboxImg");
  const lbCap = document.getElementById("lightboxCaption");

  if (lastResponseData && lastResponseData.images) {
    let src = "";
    let caption = "";
    if (mode === "clahe") {
      src = lastResponseData.images.clahe_b64;
      caption = "Prapemrosesan Penajaman Mikrokontras CIE-LAB CLAHE (Kanal L)";
    } else if (mode === "orig") {
      src = lastResponseData.images.original_b64;
      caption = "Citra Asli Helai Daun Pisang (Raw RGB)";
    } else {
      src = lastResponseData.images.annotated_b64;
      caption = `Hasil Deteksi YOLO26n: ${cleanText(lastResponseData.dominant_class || "Bercak Daun")}`;
    }

    if (lbImg) lbImg.src = src;
    if (lbCap) lbCap.textContent = caption;
    if (activeDisplayImg) activeDisplayImg.src = src;
    if (verdictActiveImg) verdictActiveImg.src = src;
  }
}

function syncLightboxTabs(mode) {
  const tAnn = document.getElementById("lbTabAnnotated");
  const tCla = document.getElementById("lbTabClahe");
  const tOri = document.getElementById("lbTabOrig");
  [tAnn, tCla, tOri].forEach((t) => {
    if (t) t.classList.remove("active");
  });
  if (mode === "clahe" && tCla) tCla.classList.add("active");
  else if (mode === "orig" && tOri) tOri.classList.add("active");
  else if (tAnn) tAnn.classList.add("active");
}

function downloadDetectionResult() {
  if (lastResponseData && lastResponseData.images && lastResponseData.images.annotated_b64) {
    const dominant = (lastResponseData.dominant_class || "Penyakit").replace(/\s+/g, "_");
    const filename = `MusaVision_Hasil_Deteksi_${dominant}.jpg`;
    const link = document.createElement("a");
    link.href = lastResponseData.images.annotated_b64;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } else if (currentLocalPreviewUrl) {
    const link = document.createElement("a");
    link.href = currentLocalPreviewUrl;
    link.download = "MusaVision_Citra_Daun.jpg";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } else {
    alert("Belum ada gambar hasil deteksi untuk diunduh.");
  }
}

// ==============================================================================
// 11. NAVIGASI MOBILE (HAMBURGER MENU DENGAN ANIMASI IKON SILANG X)
// ==============================================================================
function toggleMobileMenu(forceClose = false) {
  const drawer = document.getElementById("mobileMenuDrawer") || document.getElementById("mobileNavMenu");
  const iconOpen = document.getElementById("hamIconOpen");
  const iconClose = document.getElementById("hamIconClose");
  const btn = document.getElementById("hamburgerBtn");

  if (!drawer) return;

  const isCurrentlyOpen = drawer.classList.contains("is-open") && !drawer.classList.contains("hidden");

  if (forceClose || isCurrentlyOpen) {
    drawer.classList.remove("is-open");
    drawer.classList.add("is-closed");
    if (iconOpen) iconOpen.classList.remove("hidden");
    if (iconClose) iconClose.classList.add("hidden");
    if (btn) btn.classList.remove("is-active");
    setTimeout(() => {
      if (drawer.classList.contains("is-closed")) {
        drawer.classList.add("hidden");
      }
    }, 320);
  } else {
    drawer.classList.remove("hidden");
    drawer.classList.remove("is-open");
    drawer.classList.add("is-closed");
    // Paksa browser reflow agar animasi CSS transition terpicu
    void drawer.offsetWidth;
    drawer.classList.remove("is-closed");
    drawer.classList.add("is-open");
    if (iconOpen) iconOpen.classList.add("hidden");
    if (iconClose) iconClose.classList.remove("hidden");
    if (btn) btn.classList.add("is-active");
  }
}
window.toggleMobileMenu = toggleMobileMenu;

// ==============================================================================
// 12. PEMILIH 5 GAMBAR SAMPEL TERKURASI (CORDANA, PESTALOTIOPSIS, FRESH, BLACK, YELLOW)
// ==============================================================================
const CURATED_5_SAMPLES = [
  {
    filename: "sample_cordana.jpg",
    label: "Cordana",
    sub: "Bercak Oval",
    url: "/sample-file/samples/sample_cordana.jpg"
  },
  {
    filename: "sample_pestalotiopsis.jpg",
    label: "Pestalotiopsis",
    sub: "Nekrosis Ujung",
    url: "/sample-file/samples/sample_pestalotiopsis.jpg"
  },
  {
    filename: "sample_fresh.jpg",
    label: "Daun Segar",
    sub: "Helai Sehat",
    url: "/sample-file/samples/sample_fresh.jpg"
  },
  {
    filename: "sample_black_sigatoka.jpg",
    label: "Black Sigatoka",
    sub: "Garis Hitam",
    url: "/sample-file/samples/sample_black_sigatoka.jpg"
  },
  {
    filename: "sample_yellow_sigatoka.jpg",
    label: "Yellow Sigatoka",
    sub: "Bercak Kuning",
    url: "/sample-file/samples/sample_yellow_sigatoka.jpg"
  }
];

async function loadSampleGallery() {
  const grid = document.getElementById("sampleGalleryGrid");
  const countEl = document.getElementById("sampleGalleryCount");
  if (!grid) return;

  if (countEl) {
    countEl.textContent = "5 sampel terkurasi";
  }

  grid.innerHTML = CURATED_5_SAMPLES
    .map((s, idx) => {
      const borderClass = "border-slate-200";
      return `
        <div class="sample-card-item cursor-pointer group text-center" onclick="selectAndRunSample('${s.url}', '${s.filename}', this)">
          <div class="sample-thumb-box aspect-square w-full rounded-2xl overflow-hidden border-2 ${borderClass} group-hover:border-[#B6F035] transition duration-200 bg-slate-100 relative shadow-xs">
            <img 
              src="${s.url}" 
              alt="${cleanText(s.label)}" 
              class="w-full h-full object-cover group-hover:scale-105 transition duration-300" 
              loading="lazy" 
            />
          </div>
          <div class="text-[11px] font-semibold text-[#111812] mt-1.5 truncate leading-tight">${cleanText(s.label)}</div>
          <div class="text-[9px] text-[#68706A] truncate font-medium">${cleanText(s.sub)}</div>
        </div>
      `;
    })
    .join("");
}

async function selectAndRunSample(url, filename, el) {
  try {
    // Beri highlight kartu sampel yang diklik
    if (el) {
      document.querySelectorAll(".sample-thumb-box").forEach(box => {
        box.classList.remove("border-[#B6F035]", "ring-2", "ring-[#B6F035]/40", "shadow-sm");
        box.classList.add("border-slate-200");
      });
      const activeBox = el.querySelector(".sample-thumb-box");
      if (activeBox) {
        activeBox.classList.remove("border-slate-200");
        activeBox.classList.add("border-[#B6F035]", "ring-2", "ring-[#B6F035]/40", "shadow-sm");
      }
    }

    scrollToWorkspace();
    const idleBox = document.getElementById("idleBox");
    const loadingBox = document.getElementById("loadingBox");
    const emptyPlaceholder = document.getElementById("verdictEmptyPlaceholder");
    const activeDisplayImg = document.getElementById("activeDisplayImg");
    const verdictActiveImg = document.getElementById("verdictActiveImg");
    const fileNameBadge = document.getElementById("selectedFileName");
    const fileNameText = document.getElementById("fileNameText");

    if (idleBox) idleBox.classList.add("hidden");
    if (loadingBox) loadingBox.classList.remove("hidden");
    if (emptyPlaceholder) emptyPlaceholder.classList.add("hidden");

    // Pratinjau sampel di kartu kontrol mobile/iPad
    const previewBox = document.getElementById("controlImagePreviewBox");
    const previewImg = document.getElementById("controlPreviewImg");
    const previewBadge = document.getElementById("controlPreviewBadge");
    const emptyPrompt = document.getElementById("controlEmptyPrompt");
    const previewOverlay = document.getElementById("controlPreviewOverlay");
    if (previewBox && previewImg) {
      previewImg.src = url;
      previewImg.classList.remove("hidden");
      if (emptyPrompt) emptyPrompt.classList.add("hidden");
      if (previewOverlay) previewOverlay.classList.remove("hidden");
      if (previewBadge) previewBadge.textContent = `Sampel: ${cleanText(filename)}`;
      previewBox.classList.remove("hidden");
    }

    const res = await fetch(url);
    if (!res.ok) throw new Error("Gagal mengambil berkas sampel: " + filename);
    const blob = await res.blob();
    const file = new File([blob], filename, { type: blob.type || "image/jpeg" });

    currentFile = file;
    currentLocalPreviewUrl = url;
    currentLoadedSampleUrl = url;
    if (fileNameText) fileNameText.textContent = cleanText(filename);
    if (fileNameBadge) fileNameBadge.classList.remove("hidden");
    
    const wsPlaceholder = document.getElementById("workspacePlaceholder");
    if (wsPlaceholder) wsPlaceholder.classList.add("hidden");
    if (activeDisplayImg) {
      activeDisplayImg.src = url;
      activeDisplayImg.classList.remove("hidden");
    }
    if (verdictActiveImg) verdictActiveImg.src = url;

    // Perbarui segera gambar pada Seksi 4 saat sampel dipilih
    const solImg = document.getElementById("solutionTelemetryImg");
    if (solImg) solImg.src = url;

    // Eksekusi prediksi otomatis ke backend
    await runPrediction();
  } catch (err) {
    console.error("Gagal menjalankan uji sampel:", err);
    alert("Gagal memuat citra sampel: " + err.message);
    const loadingBox = document.getElementById("loadingBox");
    if (loadingBox) loadingBox.classList.add("hidden");
  }
}

function loadAndScanSample(filename) {
  return selectAndRunSample(`/sample-file/samples/${filename}`, filename);
}

// ==============================================================================
// 13. ANIMASI NAVBAR SCROLL (FLOATING PILL -> FULL RAPAT MENUTUP PADA SCROLL)
// ==============================================================================
function initNavbarScroll() {
  const nav = document.getElementById("mainNavbar");
  if (!nav) return;

  let ticking = false;
  window.addEventListener(
    "scroll",
    () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const scrollY = window.pageYOffset || document.documentElement.scrollTop;
          if (scrollY > 30) {
            nav.classList.add("is-scrolled");
          } else {
            nav.classList.remove("is-scrolled");
          }
          ticking = false;
        });
        ticking = true;
      }
    },
    { passive: true }
  );

  // Tutup menu drawer saat klik di luar navbar
  document.addEventListener("click", (e) => {
    const drawer = document.getElementById("mobileMenuDrawer");
    const btn = document.getElementById("hamburgerBtn");
    if (drawer && !drawer.classList.contains("hidden") && !drawer.contains(e.target) && !btn.contains(e.target)) {
      toggleMobileMenu(true);
    }
  });
}

// ==============================================================================
// 13.5 LENIS SMOOTH SCROLL, GSAP SCROLLTRIGGER, WORD-BY-WORD TITLE & CARD MOTION
// ==============================================================================

/**
 * Utilitas pembagi kata (word splitter) presisi yang mempertahankan struktur span,
 * kelas font-serif italic, warna, dan spasi antar kata tanpa merusak DOM anak.
 */
function splitElementIntoWords(el) {
  if (!el || el.dataset.wordsSplit === "true") return [];
  el.dataset.wordsSplit = "true";

  const childNodes = Array.from(el.childNodes);
  const createdWordSpans = [];

  childNodes.forEach((node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent;
      if (!text.trim()) {
        return;
      }
      const parts = text.split(/(\s+)/);
      const frag = document.createDocumentFragment();

      parts.forEach((p) => {
        if (!p) return;
        if (/^\s+$/.test(p)) {
          frag.appendChild(document.createTextNode(p));
        } else {
          const wrapper = document.createElement("span");
          wrapper.className = "split-word-wrapper";
          const inner = document.createElement("span");
          inner.className = "split-word-inner";
          inner.textContent = p;
          wrapper.appendChild(inner);
          frag.appendChild(wrapper);
          createdWordSpans.push(inner);
        }
      });
      el.replaceChild(frag, node);
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const nested = splitElementIntoWords(node);
      createdWordSpans.push(...nested);
    }
  });

  return createdWordSpans;
}

let lenisInstance = null;

/**
 * Inisialisasi Lenis Smooth Scroll dan sinkronisasi dengan GSAP Ticker & ScrollTrigger
 */
function initLenisSmoothScroll() {
  if (typeof Lenis === "undefined") return;

  try {
    lenisInstance = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: "vertical",
      gestureOrientation: "vertical",
      smoothWheel: true,
      wheelMultiplier: 1.0,
      touchMultiplier: 1.5
    });

    window.lenis = lenisInstance;

    // Sinkronisasi requestAnimationFrame Lenis dengan GSAP Ticker
    if (typeof gsap !== "undefined" && typeof ScrollTrigger !== "undefined") {
      gsap.registerPlugin(ScrollTrigger);
      lenisInstance.on("scroll", ScrollTrigger.update);
      gsap.ticker.add((time) => {
        lenisInstance.raf(time * 1000);
      });
      gsap.ticker.lagSmoothing(0);
    } else {
      function raf(time) {
        lenisInstance.raf(time);
        requestAnimationFrame(raf);
      }
      requestAnimationFrame(raf);
    }

    // Intersep navigasi anchor (#scanner, #pilar, dll.) agar di-scroll halus oleh Lenis
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener("click", function (e) {
        const href = this.getAttribute("href");
        if (href && href !== "#" && href.startsWith("#")) {
          const target = document.querySelector(href);
          if (target && lenisInstance) {
            e.preventDefault();
            lenisInstance.scrollTo(target, { offset: -70, duration: 1.1 });
          }
        }
      });
    });
  } catch (err) {
    console.warn("Lenis initialization error:", err);
  }
}

/**
 * Judul Muncul Per Kata Saat Discroll (GSAP + ScrollTrigger Word Reveal)
 */
function initTitleWordSplitAndScrollTrigger() {
  if (typeof gsap === "undefined" || typeof ScrollTrigger === "undefined") return;

  gsap.registerPlugin(ScrollTrigger);

  // Animasi Masuk Judul Hero Pertama Kali (Word by Word Cascade)
  const hMain = document.getElementById("heroHeadlineMain");
  const hSerif = document.getElementById("heroHeadlineSub");
  if (hMain && hSerif) {
    const wordsMain = splitElementIntoWords(hMain);
    const wordsSerif = splitElementIntoWords(hSerif);
    const heroWords = [...wordsMain, ...wordsSerif];
    if (heroWords.length > 0) {
      gsap.fromTo(
        heroWords,
        { yPercent: 110, opacity: 0, rotateZ: 2 },
        {
          yPercent: 0,
          opacity: 1,
          rotateZ: 0,
          duration: 0.85,
          stagger: 0.045,
          ease: "power3.out",
          delay: 0.25
        }
      );
    }
  }

  // Pilih seluruh judul seksi utama di halaman
  const sectionHeadings = document.querySelectorAll(
    "section h2, .split-words-reveal, #solution-section h2, #scan-section h2, #bento-section h2, #pathogen-section h2, #metrics-view h2, #faq-section h2"
  );

  sectionHeadings.forEach((heading) => {
    if (heading.id === "heroHeadline" || heading.closest("#hero-section")) return;
    if (heading.dataset.wordsSplit === "true") return;
    if (heading.querySelector("input, select, textarea, table")) return;

    const words = splitElementIntoWords(heading);
    if (!words || words.length === 0) return;

    gsap.fromTo(
      words,
      {
        yPercent: 110,
        opacity: 0,
        rotateZ: 2
      },
      {
        scrollTrigger: {
          trigger: heading,
          start: "top 88%",
          toggleActions: "play none none none",
          once: true
        },
        yPercent: 0,
        opacity: 1,
        rotateZ: 0,
        duration: 0.75,
        stagger: 0.038,
        ease: "power3.out"
      }
    );
  });
}

/**
 * Animasi Masuk Card (Stagger via ScrollTrigger) dan Animasi Hover Card (3D Tilt & Lift)
 */
function initCardMotionAnimations() {
  if (typeof gsap === "undefined") return;

  const cardGroupSelectors = [
    // 4 Accordion Item di Seksi Solusi
    "#solution-section div[id^='accItem']",
    // Bento Cards Tiga Pilar
    "#bento-section .grid > div",
    // 4 Parameter Kompak YOLO26n Cards
    ".grid-cols-2.lg\\:grid-cols-4 > div",
    // Katalog Patogen 5 Cards
    "#pathogen-section .grid > div",
    // Drawer Skripsi Cards
    "#skripsiDrawer .grid > div",
    // FAQ Accordion Cards
    "#faq-section .space-y-3 > div",
    // Diagnostic Cards (Bukan Form Input)
    "#initialEmptyBox",
    "#diagVerdictCard",
    "#agronomyBox",
    "#bboxTableBox",
    "#metricsAndTelemetryBox"
  ];

  const motionCards = new Set();
  cardGroupSelectors.forEach((sel) => {
    try {
      document.querySelectorAll(sel).forEach((el) => {
        el.classList.add("motion-card");
        motionCards.add(el);
      });
    } catch (e) {}
  });

  // Tambahkan juga card preview landscape
  const landscapePreview = document.querySelector("#solution-section .aspect-\\[4\\/3\\], #solution-section .aspect-\\[16\\/10\\]");
  if (landscapePreview) {
    const parent = landscapePreview.closest(".lg\\:col-span-6") || landscapePreview;
    parent.classList.add("motion-card");
    motionCards.add(parent);
  }

  // 1. ANIMASI MASUK CARD DENGAN STAGGER (SCROLLTRIGGER)
  if (typeof ScrollTrigger !== "undefined") {
    // Bento Cards (3 Pilar)
    const bentoCards = document.querySelectorAll("#bento-section .grid > div");
    if (bentoCards.length) {
      gsap.from(bentoCards, {
        scrollTrigger: { trigger: "#bento-section .grid", start: "top 85%", once: true },
        y: 45,
        opacity: 0,
        scale: 0.95,
        duration: 0.85,
        stagger: 0.12,
        ease: "power3.out",
        clearProps: "transform,opacity"
      });
    }

    // Solution Section Accordions
    const accCards = document.querySelectorAll("#solution-section div[id^='accItem']");
    if (accCards.length) {
      gsap.from(accCards, {
        scrollTrigger: { trigger: "#solution-section", start: "top 80%", once: true },
        x: -30,
        opacity: 0,
        duration: 0.75,
        stagger: 0.1,
        ease: "power3.out",
        clearProps: "transform,opacity"
      });
    }

    // Pathogen 5 Cards
    const pathogenCards = document.querySelectorAll("#pathogen-section .grid > div");
    if (pathogenCards.length) {
      gsap.from(pathogenCards, {
        scrollTrigger: { trigger: "#pathogen-section .grid", start: "top 85%", once: true },
        y: 40,
        opacity: 0,
        scale: 0.96,
        duration: 0.8,
        stagger: 0.08,
        ease: "power3.out",
        clearProps: "transform,opacity"
      });
    }

    // Parameter Stats Cards
    const statCards = document.querySelectorAll(".grid-cols-2.lg\\:grid-cols-4 > div");
    if (statCards.length) {
      gsap.from(statCards, {
        scrollTrigger: { trigger: statCards[0].parentElement, start: "top 85%", once: true },
        y: 35,
        opacity: 0,
        scale: 0.94,
        duration: 0.75,
        stagger: 0.08,
        ease: "power3.out",
        clearProps: "transform,opacity"
      });
    }

    // Scan Section Columns
    const scanCols = document.querySelectorAll("#scan-section .grid > div");
    if (scanCols.length) {
      gsap.from(scanCols, {
        scrollTrigger: { trigger: "#scan-section", start: "top 80%", once: true },
        y: 40,
        opacity: 0,
        duration: 0.85,
        stagger: 0.15,
        ease: "power3.out",
        clearProps: "transform,opacity"
      });
    }

    // FAQ Cards
    const faqCards = document.querySelectorAll("#faq-section .space-y-3 > div");
    if (faqCards.length) {
      gsap.from(faqCards, {
        scrollTrigger: { trigger: "#faq-section", start: "top 85%", once: true },
        y: 30,
        opacity: 0,
        duration: 0.7,
        stagger: 0.08,
        ease: "power3.out",
        clearProps: "transform,opacity"
      });
    }
  }

  // 2. INTERAKTIF HOVER CARD (GENTLE LIFT & 3D TILT TACTILE REACTION)
  const isTouch = window.matchMedia("(pointer: coarse)").matches;
  if (!isTouch) {
    motionCards.forEach((card) => {
      card.addEventListener("mouseenter", () => {
        gsap.to(card, {
          y: -6,
          scale: 1.012,
          duration: 0.35,
          ease: "power2.out",
          boxShadow: "0 18px 30px -10px rgba(17, 24, 18, 0.12)"
        });
      });

      card.addEventListener("mousemove", (e) => {
        const rect = card.getBoundingClientRect();
        const normX = (e.clientX - rect.left) / rect.width - 0.5;
        const normY = (e.clientY - rect.top) / rect.height - 0.5;
        gsap.to(card, {
          rotateX: -normY * 4.5,
          rotateY: normX * 4.5,
          duration: 0.25,
          ease: "power1.out",
          transformPerspective: 800
        });
      });

      card.addEventListener("mouseleave", () => {
        gsap.to(card, {
          y: 0,
          scale: 1,
          rotateX: 0,
          rotateY: 0,
          duration: 0.45,
          ease: "power3.out",
          boxShadow: "none",
          clearProps: "boxShadow,transform"
        });
      });
    });
  }
}

// ==============================================================================
// 14. ANIMASI INTERAKTIF SCROLL VARIATIF (FADE, ZOOM, LEFT, RIGHT REVEALS)
// ==============================================================================
function initScrollAnimations() {
  const elements = document.querySelectorAll(".reveal-on-scroll, .reveal-zoom, .reveal-left, .reveal-right");
  if (!elements.length) return;

  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-revealed");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.05, rootMargin: "0px 0px 40px 0px" }
    );
    elements.forEach((el) => observer.observe(el));
  } else {
    elements.forEach((el) => el.classList.add("is-revealed"));
  }
}

// ==============================================================================
// 15. ANIMASI PEMUATAN PERTAMA KALI (LOAD ANIMATIONS STAGGER)
// ==============================================================================
function initHeroLoadAnimations() {
  const headline = document.getElementById("heroHeadline");
  const subtitle = document.getElementById("heroSubtitle");
  const cta = document.getElementById("heroCta");
  const bottomBar = document.getElementById("heroBottomBar");
  const navInner = document.getElementById("mainNavbarInner");

  setTimeout(() => {
    if (navInner) navInner.classList.add("hero-animate-loaded");
  }, 80);

  setTimeout(() => {
    if (headline) headline.classList.add("hero-animate-loaded");
  }, 220);

  setTimeout(() => {
    if (subtitle) subtitle.classList.add("hero-animate-loaded");
  }, 420);

  setTimeout(() => {
    if (cta) cta.classList.add("hero-animate-loaded");
  }, 620);

  setTimeout(() => {
    if (bottomBar) bottomBar.classList.add("hero-animate-loaded");
  }, 820);
}


// ==============================================================================
// 5.5 SINKRONISASI KARTU TELEMETRI SEKSI 4 & RESET WORKSPACE
// ==============================================================================
function updateSolutionTelemetryCard(data) {
  // Seksi Tentang Kami didecouple sepenuhnya menjadi statis elegan sesuai permintaan
  // Fungsi dipertahankan sebagai no-op aman agar kompatibilitas skrip tetap terjaga
}
window.updateSolutionTelemetryCard = updateSolutionTelemetryCard;

function resetDetectionState() {
  currentFile = null;
  currentLocalPreviewUrl = "";
  currentLoadedSampleUrl = null;
  lastResponseData = null;

  const imageInput = document.getElementById("imageInput");
  const cameraInput = document.getElementById("cameraInput");
  if (imageInput) imageInput.value = "";
  if (cameraInput) cameraInput.value = "";

  const selectedFileName = document.getElementById("selectedFileName");
  if (selectedFileName) selectedFileName.classList.add("hidden");

  // Reset kotak pratinjau kontrol ke status kosong awal
  const previewBox = document.getElementById("controlImagePreviewBox");
  const previewImg = document.getElementById("controlPreviewImg");
  const emptyPrompt = document.getElementById("controlEmptyPrompt");
  const previewOverlay = document.getElementById("controlPreviewOverlay");
  if (previewImg) {
    previewImg.src = "";
    previewImg.classList.add("hidden");
  }
  if (emptyPrompt) emptyPrompt.classList.remove("hidden");
  if (previewOverlay) previewOverlay.classList.add("hidden");
  if (previewBox) previewBox.classList.remove("hidden");

  const loadingBox = document.getElementById("loadingBox");
  const rejectedBox = document.getElementById("rejectedBox");
  const noDetectionBox = document.getElementById("noDetectionBox");
  const agronomyBox = document.getElementById("agronomyBox");
  if (loadingBox) loadingBox.classList.add("hidden");
  if (rejectedBox) rejectedBox.classList.add("hidden");
  if (noDetectionBox) noDetectionBox.classList.add("hidden");
  if (agronomyBox) agronomyBox.classList.remove("hidden");

  // Matikan seluruh garis laser pemindaian
  const controlLaser = document.getElementById("controlLaserScan");
  const controlOverlay = document.getElementById("controlLaserOverlay");
  const workspaceLaser = document.getElementById("workspaceLaserScan");
  const workspaceOverlay = document.getElementById("workspaceLaserOverlay");
  if (controlLaser) controlLaser.classList.add("hidden");
  if (controlOverlay) controlOverlay.classList.add("hidden");
  if (workspaceLaser) workspaceLaser.classList.add("hidden");
  if (workspaceOverlay) workspaceOverlay.classList.add("hidden");

  // Reset kanvas/images ke status placeholder awal
  const wsPlaceholder = document.getElementById("workspacePlaceholder");
  const activeDisplayImg = document.getElementById("activeDisplayImg");
  const verdictActiveImg = document.getElementById("verdictActiveImg");
  if (wsPlaceholder) wsPlaceholder.classList.remove("hidden");
  if (activeDisplayImg) {
    activeDisplayImg.src = "";
    activeDisplayImg.classList.add("hidden");
  }
  if (verdictActiveImg) verdictActiveImg.src = "";

  // Reset 3 thumbnail perbandingan di bawah kanvas (Bebas dari Broken Image Icon)
  const imgOrig = document.getElementById("imgOrig");
  const imgClahe = document.getElementById("imgClahe");
  const imgAnnotated = document.getElementById("imgAnnotated");
  const phOrig = document.getElementById("phImgOrig");
  const phClahe = document.getElementById("phImgClahe");
  const phAnnotated = document.getElementById("phImgAnnotated");
  const bdOrig = document.getElementById("badgeImgOrig");
  const bdClahe = document.getElementById("badgeImgClahe");
  const bdAnnotated = document.getElementById("badgeImgAnnotated");

  if (imgOrig) { imgOrig.src = ""; imgOrig.classList.add("hidden"); }
  if (imgClahe) { imgClahe.src = ""; imgClahe.classList.add("hidden"); }
  if (imgAnnotated) { imgAnnotated.src = ""; imgAnnotated.classList.add("hidden"); }
  if (phOrig) phOrig.classList.remove("hidden");
  if (phClahe) phClahe.classList.remove("hidden");
  if (phAnnotated) phAnnotated.classList.remove("hidden");
  if (bdOrig) bdOrig.classList.add("hidden");
  if (bdClahe) bdClahe.classList.add("hidden");
  if (bdAnnotated) bdAnnotated.classList.add("hidden");

  // Reset tabel Bounding Box ke status kosong awal
  const bboxBody = document.getElementById("bboxTableBody");
  if (bboxBody) {
    bboxBody.innerHTML = `
      <tr>
        <td colspan="6" class="py-6 px-4 text-center text-xs text-[#68706A]">
          Belum ada pengujian daun yang dijalankan.
        </td>
      </tr>`;
  }

  // Reset diagnosis ke status belum ada analisis
  const initialEmptyBox = document.getElementById("initialEmptyBox");
  const visualResultBox = document.getElementById("visualResultBox");
  if (initialEmptyBox) initialEmptyBox.classList.remove("hidden");
  if (visualResultBox) visualResultBox.classList.add("hidden");

  // Hapus tanda aktif pada seluruh sampel galeri
  document.querySelectorAll(".sample-thumb-box").forEach(box => {
    box.classList.remove("border-[#B6F035]", "ring-2", "ring-[#B6F035]/40", "shadow-sm");
    box.classList.add("border-slate-200");
  });

  // Reset penanda spektrum
  const severityMarker = document.getElementById("severityMarker");
  if (severityMarker) severityMarker.style.left = "88%";

  // Reset telemetri counters
  const lesionCount = document.getElementById("lesionCount");
  const leafCount = document.getElementById("leafCount");
  const latServer = document.getElementById("latServer");
  const totalDet = document.getElementById("totalDetCount");
  if (lesionCount) lesionCount.textContent = "0";
  if (leafCount) leafCount.textContent = "0";
  if (latServer) latServer.textContent = "0 ms";
  if (totalDet) totalDet.textContent = "0";

  // Reset card di seksi 4
  updateSolutionTelemetryCard(null);

  // Clear active sample selection borders
  document.querySelectorAll("#sampleListContainer .sample-card").forEach((c) => {
    c.classList.remove("ring-2", "ring-[#B6F035]", "border-[#B6F035]");
    c.classList.add("border-slate-200");
  });
}
window.resetDetectionState = resetDetectionState;

// ==============================================================================
// 5.6 MODAL DETAIL & PROTOKOL PENANGANAN PATOGEN
// ==============================================================================
const PATHOGEN_CATALOG = {
  black_sigatoka: {
    title: "Sigatoka Hitam (Black Sigatoka)",
    sci: "Pseudocercospora fijiensis",
    img: "/static/samples/sample_black_sigatoka.jpg",
    sampleFile: "sample_black_sigatoka.jpg",
    severity: "Ganas · Kritis",
    severityClass: "bg-rose-100 text-rose-800 border-rose-300",
    frac: "FRAC 3, 11 (Sistemik) · FRAC M01, M02 (Multisite)",
    fracClass: "bg-emerald-100 text-emerald-900 border-emerald-300",
    summary: "Penyakit jamur bercak daun pisang paling destruktif di dunia yang merusak fotosintesis dan memicu kegagalan panen.",
    symptoms: "Dimulai dari garis kemerahan/cokelat halus sejajar tulang daun (stadium 1–2). Lesi melebar menjadi elips dengan halo kuning (stadium 3–4), dan akhirnya pusat lesi mengering menjadi cekung kelabu gelap (stadium 5–6) yang memproduksi jutaan ascospora infektif saat udara lembap.",
    impact: "Merusak jaringan fotosintesis hingga 80%, memicu pematangan dini buah (premature ripening), menurunkan bobot tandan hingga 50%, dan menyebabkan buah membusuk saat transportasi.",
    deleafing: "Lakukan sanitasi deleafing selektif berkala setiap 7–10 hari dengan memotong helai daun stadium 4–5 atau memotong separuh helai daun nekrotik. Telungkupkan potongan daun ke tanah agar spora tidak diterbangkan angin.",
    fracGuide: "Rotasikan fungisida kontak multisite (Mankozeb FRAC M01 / Tembaga FRAC M02) dengan sistemik (Difenokonazol / Tebukonazol FRAC 3) dan Azoksistrobin (FRAC 11). Batasi pemakaian kelas sistemik maksimal 2 kali berturut-turut untuk mencegah mutasi ras kebal."
  },
  yellow_sigatoka: {
    title: "Sigatoka Kuning (Yellow Sigatoka)",
    sci: "Pseudocercospora musae",
    img: "/static/samples/sample_yellow_sigatoka.jpg",
    sampleFile: "sample_yellow_sigatoka.jpg",
    severity: "Sedang · Klorotik Aktif",
    severityClass: "bg-amber-100 text-amber-800 border-amber-300",
    frac: "FRAC 3 (Triazol) · FRAC M01 (Mankozeb)",
    fracClass: "bg-emerald-100 text-emerald-900 border-emerald-300",
    summary: "Penyakit bercak daun klorotik yang dominan di dataran tinggi dan musim hujan dingin, menurunkan kualitas buah pisang.",
    symptoms: "Muncul sebagai bercak kuning pucat memanjang pada daun muda ke-2 atau ke-3. Lesi membesar dengan halo kuning cerah dominan dan tepi cokelat berbatas tegas, membentuk pita nekrotik.",
    impact: "Mengurangi luas daun fungsional fotosintesis, menghambat translokasi karbohidrat saat pengisian tandan, dan menurunkan ukuran panjang jari buah pisang.",
    deleafing: "Tingkatkan sirkulasi udara dengan memangkas anakan berlebih (pertahankan 2–3 anakan per rumpun), jaga parit drainase agar tidak tergenang, dan pangkas helai daun tua terinfeksi.",
    fracGuide: "Semprotkan fungisida protektan Mankozeb (FRAC M01) pada awal musim hujan. Jika bercak aktif meluas, aplikasikan campuran fungisida sistemik FRAC 3 (Tebukonazol) dengan penambahan minyak mineral pertanian."
  },
  cordana: {
    title: "Bercak Daun Cordana (Cordana Leaf Spot)",
    sci: "Cordana musae",
    img: "/static/samples/sample_cordana.jpg",
    sampleFile: "sample_cordana.jpg",
    severity: "Oportunistik · Tepi Cincin",
    severityClass: "bg-amber-100 text-amber-900 border-amber-300",
    frac: "FRAC M02 (Tembaga) · FRAC M01 (Mankozeb)",
    fracClass: "bg-emerald-100 text-emerald-900 border-emerald-300",
    summary: "Penyakit bercak daun sekunder dengan pola cincin konsentris khas yang menyerang helai daun stres atau terluka.",
    symptoms: "Bercak oval atau elips besar tidak beraturan dengan tepi bergerigi. Ciri khas utama adalah adanya garis cincin konsentris bergelombang (target board pattern) berwarna cokelat tua yang dikelilingi pita halo kuning mencolok.",
    impact: "Mempercepat robek dan mengeringnya tepi helaian daun pisang, terutama pada tanaman yang terkena gesekan angin kencang atau kekurangan nutrisi kalium.",
    deleafing: "Pasang windbreak (tanaman penahan angin) di batas kebun untuk mengurangi luka gesekan antarhelai daun. Pangkas helai daun yang mengering dan lakukan sanitasi seresah di pangkal pohon.",
    fracGuide: "Aplikasi fungisida protektan berbasis tembaga hidroksida / tembaga oksiklorida (FRAC M02) berseling mankozeb (FRAC M01). Berikan pupuk kalium dan silika untuk mempertebal lapisan kutikula daun."
  },
  pestalotiopsis: {
    title: "Bercak Daun Pestalotiopsis",
    sci: "Pestalotiopsis microspora",
    img: "/static/samples/sample_pestalotiopsis.jpg",
    sampleFile: "sample_pestalotiopsis.jpg",
    severity: "Nekrotik Tepi Hitam",
    severityClass: "bg-slate-100 text-slate-800 border-slate-300",
    frac: "FRAC M01 (Dithiokarbamat) · FRAC 3 (Triazol)",
    fracClass: "bg-emerald-100 text-emerald-900 border-emerald-300",
    summary: "Bercak abu-abu memutih dengan batas hitam tegas yang menyerang daun tua atau tanaman yang mengalami cekaman hara.",
    symptoms: "Bercak bulat hingga elips dengan pusat lesi berwarna putih kelabu atau abu-abu pucat, dibatasi oleh garis tepi cokelat gelap hingga hitam pekat yang sangat tegas. Tampak titik-titik hitam kecil (aservulus jamur) saat lembap.",
    impact: "Biasanya menyerang daun bawah yang tua atau tanaman yang mengalami defisiensi kalium/kalsium. Nekrosis dapat menyatu menyebabkan seluruh helai daun mengering prematur.",
    deleafing: "Pangkas helai daun tua berpenyakit pada kanopi bagian bawah secara rutin, bersihkan serasah di sekitar pangkal rumpun, dan perbaiki aerasi perakaran melalui pemupukan organik seimbang.",
    fracGuide: "Aplikasi fungisida kontak mankozeb (FRAC M01) atau klorotalonil (FRAC M05). Lakukan penyemprotan terarah pada permukaan bawah helai daun saat spora mulai aktif berkecambah."
  },
  healthy: {
    title: "Daun Pisang Sehat (Optimal Canopy)",
    sci: "Musa spp. Functional Foliage",
    img: "/static/samples/sample_fresh.jpg",
    sampleFile: "sample_fresh.jpg",
    severity: "Optimal · Bebas Lesi",
    severityClass: "bg-emerald-100 text-emerald-800 border-emerald-300",
    frac: "Proteksi Preventif Non-Kimia",
    fracClass: "bg-emerald-100 text-emerald-900 border-emerald-300",
    summary: "Helai daun fungsional fotosintesis optimal yang wajib dipertahankan untuk menjamin produktivitas tandan pisang.",
    symptoms: "Helai daun berwarna hijau segar pekat merata, pertulangan daun kokoh, turgor sel maksimal, dan permukaan helai daun mulus tanpa adanya lesi bercak nekrotik, klorosis, maupun jelaga jamur.",
    impact: "Pohon pisang memerlukan minimal 8–10 helai daun fungsional sehat saat keluar jantung dan minimal 5–6 daun sehat hingga panen untuk menjamin pengisian buah optimal.",
    deleafing: "Tidak memerlukan deleafing kuratif. Hindari pemangkasan berlebihan pada daun sehat agar tanaman tidak kehilangan sumber fotosintat utama untuk pengisian buah.",
    fracGuide: "Tidak memerlukan fungisida kimia. Terapkan aplikasi agens hayati Trichoderma harzianum atau pupuk mikroorganisme protektif untuk mencegah kolonisasi spora patogen liar."
  }
};

// ==============================================================================
// 16. ENSIKLOPEDIA & KATALOG PATOGEN (DEDICATED FULL PAGE /katalog-patogen)
// ==============================================================================
function selectPathogenCatalog(key) {
  if (window.location.pathname.includes("/katalog-patogen")) {
    if (typeof switchPathogenPage === "function") {
      switchPathogenPage(key);
    }
  } else {
    window.location.href = `/katalog-patogen?penyakit=${encodeURIComponent(key)}`;
  }
}
window.selectPathogenCatalog = selectPathogenCatalog;

function runPathogenSampleFromPage(key) {
  window.location.href = `/#scan-section`;
}
window.runPathogenSampleFromPage = runPathogenSampleFromPage;

function openPathogenDetailModal(key) {
  selectPathogenCatalog(key);
}
window.openPathogenDetailModal = openPathogenDetailModal;

function closePathogenDetailModal() {
  const modal = document.getElementById("pathogenDetailModal");
  if (modal) modal.classList.add("hidden");
  document.body.classList.remove("overflow-hidden");
}
window.closePathogenDetailModal = closePathogenDetailModal;

function runPathogenSampleFromModal() {
  window.location.href = `/#scan-section`;
}
window.runPathogenSampleFromModal = runPathogenSampleFromModal;
